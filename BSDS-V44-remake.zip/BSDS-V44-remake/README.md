BSDS 44 REMAKE
How To Run
1) edit ip and port in apk
2) open Core.py and start